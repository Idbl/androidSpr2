package com.example.sprawdzianandroid2;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String tytul[] = {"a", "b", "c", "d", "f", "g", "h"};
    String autor[] = {"a", "b", "c", "d", "f", "g", "h"};
    //int kisazka[] = {R.drawable.1, R.drawable.2, R.drawable.3, R.drawable.4, R.drawable.5, R.drawable.6, R.drawable.7};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //String
        //int frutlist[] = {R.drawable.apple}
        //TextView pole = findBiewById(R.id.pole1)
        //button.setObClickListener((Viev v) ->{}
        //getText().toString()
        //setText(dane.toString())
        // getText().toString() == ""

        TextView tytul = findViewById(R.id.tytul);
        TextView autor = findViewById(R.id.autor);
        for (int i=0; i<tytul.length(); i++){

        }

        button.setOnClickListener((View v) -> {
            tytul.getText().toString();
            autor.getText().toString();
        })

    }
}