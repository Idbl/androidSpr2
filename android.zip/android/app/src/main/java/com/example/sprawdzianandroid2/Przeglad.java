package com.example.sprawdzianandroid2;

public class Przeglad {
}
